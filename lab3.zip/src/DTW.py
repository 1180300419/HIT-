import numpy as np
'''
实现DTW算法的类
'''
class DTW:

    def get_distance(self, vec1, vec2):
        dis_sum = 0
        length = len(vec1)
        for i in range(length):
            dis_sum = dis_sum + np.power(vec1[i] - vec2[i], 2)
        return dis_sum
    '''
    返回feature1和feature2这两个矩阵之间的最短距离
    '''
    def dtw(self, feature1, feature2):
        # 获得两个特征的个数
        M1 = len(feature1)
        M2 = len(feature2)
        dis = np.zeros((M1, M2))
        # 初始化
        dis[0, 0] = self.get_distance(feature1[0], feature2[0])
        for i in range(1, M1):
            dis[i, 0] = dis[i - 1, 0] + self.get_distance(feature1[i], feature2[0])
        for j in range(1, M2):
            dis[0, j] = dis[0, j - 1] + self.get_distance(feature1[0], feature2[j])
        # 动态规划的递推阶段
        for i in range(1, M1):
            for j in range(1, M2):
                disij = self.get_distance(feature1[i], feature2[j])
                dis[i, j] = min(dis[i, j - 1] + disij, dis[i - 1, j] + disij, dis[i - 1, j - 1] + disij * 2)
        return dis[M1 - 1, M2 - 1] / (M1 + M2)


