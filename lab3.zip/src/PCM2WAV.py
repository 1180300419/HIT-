import wave
'''
将pcm文件转换成wav文件格式
'''
class PCM2WAV:
    def pcm2wav(self):
        for i in range(1, 6):
            for j in range(1, 11):
                filename = '../pcm/' + str(i) + '_' + str(j) + '.pcm'
                targetfile = '../data_ne/' + str(i) + '_' + str(j) + '.wav'
                pcmfile = open(filename, 'rb')
                pcmdata = pcmfile.read()
                with wave.open(targetfile, 'wb') as wavfile:
                    wavfile.setparams((1, 2, 16000, 0, 'NONE', 'NONE'))
                    wavfile.writeframes(pcmdata)

