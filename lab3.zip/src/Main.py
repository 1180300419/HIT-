import EndPointDetection
import PCM2WAV
import readMFCC
'''
调用其他文件的脚本文件
'''
endPointDetection = EndPointDetection.EndPointDetection()
endPointDetection.process()

pcm2wav = PCM2WAV.PCM2WAV()
pcm2wav.pcm2wav()

readmfcc = readMFCC.ReadMFCC()
features = []  # 存储模板文件的特征模板
for i in range(1, 6):
    filename = '../mfcc/' + str(i) + '_1.mfcc'
    features.append(readmfcc.readMFCC(filename))

import numpy as np
import DTW
dtw = DTW.DTW()
distance = np.zeros(5)
correct_sum = 0
for i in range(1, 6):
    for j in range(2, 11):
        for k in range(5):
            filename = '../mfcc/' + str(i) + '_' + str(j) + '.mfcc'
            feature = readmfcc.readMFCC(filename)
            distance[k] = dtw.dtw(features[k], feature)
        if distance.argmin() + 1 == i:
            correct_sum += 1
print('正确率为: ', correct_sum / 45 * 100, '%')
