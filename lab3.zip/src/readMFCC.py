import struct
'''
读取mfcc文件，返回读取的数据
'''
class ReadMFCC:
    ''''''
    '''
    读取filename指示的文件，返回其mfcc，每行表示一帧的mfcc系数
    '''
    def readMFCC(self, filename):
        f = open(filename, "rb")
        nframes = struct.unpack(">i", f.read(4))[0]
        frate = struct.unpack(">i", f.read(4))[0]
        nbytes = struct.unpack(">h", f.read(2))[0]
        feakind = struct.unpack(">h", f.read(2))[0]
        ndim = nbytes / 4
        features = []  #
        for m in range(nframes):
            feature = []
            for n in range(int(ndim)):
                feature.append(struct.unpack(">f", f.read(4))[0])
            features.append(feature)
        f.close()
        return features
